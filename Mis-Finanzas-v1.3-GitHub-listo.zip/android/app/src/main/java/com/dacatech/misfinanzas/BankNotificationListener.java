package com.dacatech.misfinanzas;

import android.app.Notification;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.regex.Pattern;

/**
 * Escucha las notificaciones del teléfono (apps de bancos, Nequi, SMS bancarios...)
 * y guarda en el propio teléfono solo las que parecen movimientos de dinero.
 * Nada sale del dispositivo. La app web las lee con BankNotificationsPlugin.getPending().
 */
public class BankNotificationListener extends NotificationListenerService {

    static final String PREFS = "bank_notifications";
    static final String KEY_PENDING = "pending";
    private static final int MAX_PENDING = 200;
    private static final Object LOCK = new Object();

    private static final Pattern HAS_AMOUNT = Pattern.compile("(?:\\$\\s?|\\bCOP\\s*|\\bpesos?\\s*)\\d", Pattern.CASE_INSENSITIVE);
    private static final Pattern IS_TX = Pattern.compile(
            "compra|compraste|pago|pagaste|retiro|retiraste|transferencia|transferiste|enviaste|"
                    + "recibiste|recib[ií]|abono|consignaci|dep[oó]sito|d[eé]bito|cr[eé]dito|n[oó]mina|"
                    + "te enviaron|te transfirieron|avance|transferencia exitosa|transacci[oó]n aprobada|"
                    + "compra aprobada|pago exitoso|dinero ingres[oó]|movimiento en tu cuenta",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    /** Apps que nunca son del banco: se ignoran para no leer chats ni correos. */
    private static final String[] IGNORED = {
            "com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger", "com.google.android.gm",
            "com.facebook.katana", "com.facebook.orca", "com.instagram.android",
            "com.twitter.android", "com.android.vending", "com.dacatech.misfinanzas"
    };

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            if (sbn == null || sbn.getNotification() == null) return;
            String pkg = sbn.getPackageName();
            for (String ig : IGNORED) {
                if (ig.equals(pkg)) return;
            }
            Notification n = sbn.getNotification();
            if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;

            Bundle ex = n.extras;
            if (ex == null) return;
            CharSequence title = ex.getCharSequence(Notification.EXTRA_TITLE);
            CharSequence big = ex.getCharSequence(Notification.EXTRA_BIG_TEXT);
            CharSequence text = big != null ? big : ex.getCharSequence(Notification.EXTRA_TEXT);
            String t = title == null ? "" : title.toString();
            String body = text == null ? "" : text.toString();
            String full = (t + " " + body).trim();

            if (full.isEmpty() || !HAS_AMOUNT.matcher(full).find() || !IS_TX.matcher(full).find()) return;

            JSONObject o = new JSONObject();
            o.put("id", pkg + "|" + sbn.getId() + "|" + sbn.getPostTime());
            o.put("pkg", pkg);
            o.put("title", t);
            o.put("text", body);
            o.put("time", sbn.getPostTime());
            append(getApplicationContext(), o);
        } catch (Exception ignored) {
            // Nunca romper el servicio por una notificación rara.
        }
    }

    private static void append(Context ctx, JSONObject o) throws Exception {
        synchronized (LOCK) {
            SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(sp.getString(KEY_PENDING, "[]"));
            String id = o.getString("id");
            for (int i = 0; i < arr.length(); i++) {
                if (id.equals(arr.getJSONObject(i).optString("id"))) return;
            }
            arr.put(o);
            // Conserva solo las más recientes.
            if (arr.length() > MAX_PENDING) {
                JSONArray cut = new JSONArray();
                for (int i = arr.length() - MAX_PENDING; i < arr.length(); i++) cut.put(arr.get(i));
                arr = cut;
            }
            sp.edit().putString(KEY_PENDING, arr.toString()).apply();
        }
    }

    /** Devuelve (como texto JSON) todo lo pendiente y lo vacía. */
    static String popAll(Context ctx) {
        synchronized (LOCK) {
            SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String s = sp.getString(KEY_PENDING, "[]");
            sp.edit().putString(KEY_PENDING, "[]").apply();
            return s;
        }
    }
}
