/* Configura estos valores en Supabase antes de usar cuentas reales. */
window.MIS_FINANZAS_SUPABASE_URL = 'https://TU-PROYECTO.supabase.co';
window.MIS_FINANZAS_SUPABASE_ANON_KEY = 'PEGA_AQUI_TU_CLAVE_PUBLICA_ANON';
